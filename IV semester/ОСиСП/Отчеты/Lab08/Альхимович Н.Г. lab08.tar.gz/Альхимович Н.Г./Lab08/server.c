//
//  server.c
//  Lab08
//
//  Created by Нина Альхимович on 08.06.23.
//

#define _POSIX_C_SOURCE 200809L

#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#define num_of_clients 10

typedef struct
{
    int socket;
    char current_dir[256];
} Client;

void *process_client(void *arg)
{
    char input[1024], *dir, new_path[256];
    Client *client = (Client *)arg;
    int socket_client = client->socket, received, len;

    dir = (char *) calloc(256, sizeof(char));
    if(!dir)
    {
        fprintf(stderr, "Память не выделена\n");
        return NULL;
    }

    FILE *file = fopen("info.txt", "r");
    if(!file)
    {
        fprintf(stderr, "Невозможно открыть файл\n");
        return NULL;
    }

    else
    {
        while(fgets(input, 1024, file) != NULL)
            if(send(socket_client, input, strlen(input), 0) == -1)
            {
                printf("Ошибка отправки сообщения\n");
                break;
            }
    }

    fclose(file);

    printf("Ожидание сообщений клиента...\n");

    while(1)
    {
        char input[1024];
        memset(input, 0, sizeof(input));

        received = recv(socket_client, input, 1024, 0);
        if(received <= 0)
        {
            printf("Ошибка или клиент отключился\n");
            break;
        }
        else
        {
            printf("Команда %s поступила от клиента\n", input);
            if(input[received - 1] == '\n')
            {
                printf("Информация от сервера получена\n");
                break;
            }
        }

        if(strncmp(input, "ECHO ", 5) == 0)
        {
            printf("%s\n", input);
            char echo[1024];
            strcpy(echo, input+5);
            strcat(echo, "\n");

            if(send(socket_client, echo, strlen(echo), 0) == -1)
            {
                printf("Ошибка отправки сообщения\n");
                break;
            }
        }

        else if(strcmp(input, "QUIT") == 0)
        {
            printf("%s\n", input);

            printf("Завершение сеанса...\n");
            close(socket_client);
            break;
        }

        else if(strcmp(input, "INFO") == 0)
        {
            printf("%s\n", input);

            FILE *file = fopen("info.txt", "r");
            if(!file)
            {
                fprintf(stderr, "Невозможно открыть файл\n");
                return NULL;
            }

            else
            {
                while(fgets(input, 1024, file) != NULL)
                    if(send(socket_client, input, strlen(input), 0) == -1)
                    {
                        printf("Ошибка отправки сообщения\n");
                        break;
                    }
            }
        }

        else if(strncmp(input, "CD ", 3) == 0)    //3 - ?
        {
            printf("%s\n", input);

            dir = input + 3;
            len = strlen(dir);

            if(len > 0 && dir[len-1] == '\n')
                dir[len-1] = '\0';

            //snprintf(new_path, sizeof(new_path), "%s/%s", client->current_dir, dir);    //формировние нового пути
            strcpy(new_path, dir);

            if(realpath(new_path, NULL) == NULL)
            {
                if(send(socket_client, "Wrong path\n", 11, 0) == -1)
                {
                    printf("Ошибка отправки сообщения\n");
                    break;
                }
            }
            else
            {
                strcpy(client->current_dir, new_path);
                if(send(socket_client, "Path changed\n", 13, 0) == -1)
                {
                    printf("Ошибка отправки сообщения\n");
                    break;
                }
            }
        }

        else if(strcmp(input, "LIST") == 0)
        {
            printf("%s\n", input);

            char path_name[1024], sent[1024] = {};
            struct dirent *dir_entry = NULL;    //элемент каталога
            DIR *dir = NULL;
            struct stat buffer;

            if((dir = opendir(client->current_dir)) == NULL)
            {
                fprintf(stderr, "Невозможно открыть данный каталог %s: %s\n", client->current_dir, strerror(errno));
                break;
            }

            while((dir_entry = readdir(dir)) != NULL)
            {
                if(strcmp(dir_entry->d_name, ".") == 0 || strcmp(dir_entry->d_name, "..") == 0)
                    continue;    //пропустить данный каталог и родительский

                if(strlen(client->current_dir) + strlen(dir_entry->d_name) + 2 > sizeof(path_name))
                    fprintf(stderr, "Слишком длинное имя: %s %s\n", client->current_dir, dir_entry->d_name);

                else
                {
                    strcpy(path_name, client->current_dir);    //дополняется путь
                    strcat(path_name, "/");
                    strcat(path_name, dir_entry->d_name);
                }

                if(lstat(path_name, &buffer) == 0)    //получение информации о файле
                {
                    if(S_ISDIR(buffer.st_mode))
                    {
                        strcat(sent, path_name);
                        strcat(sent, "/\n");
                    }

                    else if(S_ISREG(buffer.st_mode))
                    {
                        strcat(sent, path_name);
                        strcat(sent, "\n");
                    }

                    else if(S_ISLNK(buffer.st_mode))
                    {
                        strcat(sent, path_name);
                        strcat(sent, "\n");
                    }

                    else
                    {
                        strcat(sent, "\n");
                    }
                }
            }

            closedir(dir);

            strcat(sent, "\n");

            if(send(socket_client, sent, strlen(sent), 0) == -1)
            {
                printf("Ошибка отправки сообщения\n");
                break;
            }
        }

        else
        {
            printf("%s\n", input);

            if(send(socket_client, "Неизвестная команда\n", 38, 0) == -1)
            {
                printf("Ошибка отправки сообщения\n");
                break;
            }
        }
    }

    close(socket_client);
    free(client);
    //pthread_detach(pthread_self());

    return NULL;
}

int main(int argc, const char *argv[])
{
    if(argc != 2)
    {
        fprintf(stderr, "При запуске сервера необходимо указать путь к корневому каталогу\n");
        return -1;
    }

    int socket_serv, socket_client;
    struct sockaddr_in address_serv, address_clnt;

    char *root_dir = (char *) calloc(256, sizeof(char));
    if(!root_dir)
    {
        fprintf(stderr, "Память не выделена\n");
        return -1;
    }
    strcpy(root_dir, argv[1]);

    socket_serv = socket(AF_INET, SOCK_STREAM, 0);
    if(socket_serv == -1)
    {
        fprintf(stderr, "Ошибка создания сокета\n");
        return -1;
    }

    address_serv.sin_family = AF_INET;
    address_serv.sin_addr.s_addr = INADDR_ANY;
    address_serv.sin_port = htons(1326);
    memset(address_serv.sin_zero, '\0', sizeof(address_serv.sin_zero));

    if(bind(socket_serv, (struct sockaddr *)&address_serv, sizeof(address_serv)) == -1)    //привязка сокета к адресу сервера
    {
        fprintf(stderr, "Ошибка привязки сокета\n");
        return -1;
    }

    if(listen(socket_serv, num_of_clients) == -1)    //ожидать подключение
    {
        fprintf(stderr, "Невозможно прослушивать входящие соединения\n");
        return -1;
    }

    printf("Сервер запущен. Корневой каталог: %s\n", root_dir);

    //ожидание и обработка входящих соединений
    while(1)
    {
        struct sockaddr_in address_clnt;

        socklen_t len_clnt = sizeof(address_clnt);
        socket_client = accept(socket_serv, (struct sockaddr *)&address_clnt, &len_clnt);
        if(socket_client == -1)
        {
            fprintf(stderr, "Ошибка соединения\n");
            return -1;
        }

        Client *client = (Client *) calloc(1, sizeof(Client));
        if(!client)
        {
            fprintf(stderr, "Память не выделена\n");
            return -1;
        }
        client->socket = socket_client;
        strcpy(client->current_dir, root_dir);

        pthread_t client_thread;
        if(pthread_create(&client_thread, NULL, process_client, (void*)client) != 0)
        {
            fprintf(stderr, "Ошибка открытия потока\n");
            return -1;
        }

        pthread_detach(client_thread);
    }

    free(root_dir);
    close(socket_serv);

    return 0;
}
