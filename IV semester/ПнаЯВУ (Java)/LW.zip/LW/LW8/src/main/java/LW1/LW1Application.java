package LW1;

//import LW1.database.DatabaseConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LW1Application {
    public static void main(String[] args) {
        SpringApplication.run(LW1.LW1Application.class, args);
    }
}