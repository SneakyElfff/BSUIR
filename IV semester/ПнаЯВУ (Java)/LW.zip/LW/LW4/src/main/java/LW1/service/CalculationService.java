package LW1.service;

public interface CalculationService {
    Double findMean(Double num1, Double num2, Double num3, Double num4);

    Double findMedium(Double num1, Double num2, Double num3, Double num4);
}
